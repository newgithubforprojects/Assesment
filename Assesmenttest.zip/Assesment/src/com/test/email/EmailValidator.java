package com.test.email;

public class EmailValidator {

	public static void main(String[] args) {
		String email = "test01*gmail.com";
		boolean isValid = validateEmail(email);
		
		if (isValid) {
			System.out.println("");
		} else {
			System.out.println("error:invalid Email id");
        }
	}
		public static boolean validateEmail(String email) {
			if (email == null || email.isEmpty()) {
				return false;
				}
			boolean hasAtSymbol1 = false;
			boolean hasDot2 = false;
			boolean validCharacterBeforeAt3 = false;
			boolean validCharacterAftereAt4 = false;
			
			for (int i = 0; i< email.length(); i ++) {
				char ch = email.charAt(i);
				
				if (ch == '@') {
					if (hasAtSymbol1 || i == 0 ||i==email.length() -1) {
						return false;
					}
					hasAtSymbol1 = true;
					validCharacterBeforeAt3 = true;
				}else if (ch == '.') {
					if(i==0|| i == email.length()-1||!validCharacterBeforeAt3) {
						return false;
					}
					hasDot2 = true;
					validCharacterAftereAt4 = true;
				}else if ((ch>='a'&& ch<='z')||(ch>='A'&& ch<='z') || (ch >= '0' && ch <='9')){
					if (hasAtSymbol1 && ! validCharacterAftereAt4) {
						validCharacterAftereAt4 = true;
						
					} else {
                          return false;
					}
					
				}
				return hasAtSymbol1 && hasDot2 && validCharacterBeforeAt3 && validCharacterAftereAt4;
				}
			return validCharacterAftereAt4;
		}
	}
					
					
					
					
					
					
					
					
					
					
					
		
