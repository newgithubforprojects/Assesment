package com.jbk.num;

public class B {
	
	public int getLastDigit(int number)
	{
		return number % 10;
	}

}
