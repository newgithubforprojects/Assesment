package com.jbk.num;

public class Main {

	public static void main(String[] args) {
		A numbers = new A(111,222);
		int number1 = numbers.getNumber1();
		int number2 = numbers.getNumber2();
		
		C mult = new C();
		int result = mult.multiplylastDigit(number1, number2);
		
		System.out.println("multiplication of last digit:" +result);
		
		
	}

}
