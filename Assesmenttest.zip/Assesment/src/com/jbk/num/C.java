package com.jbk.num;

public class C {
	
	public int multiplylastDigit(int number1, int number2) {
		
		B b1 = new B();
		int lastdigit1 = b1.getLastDigit(number1);
		int lastdigit2 = b1.getLastDigit(number2);
		
		b1.getLastDigit(number2);
		
		return lastdigit1 * lastdigit2;
		
		
	}

}
